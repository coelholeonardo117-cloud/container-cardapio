# Container do Espetinho – Cardápio digital

Site estático (HTML/CSS/JS puro), sem dependências, sem cookies, sem formulários e sem chamadas a servidores externos. Os pedidos abrem o WhatsApp (69) 99261-4430.

## Como publicar (grátis)
- **Netlify:** arraste esta pasta em app.netlify.com/drop. O arquivo `_headers` aplica a segurança.
- **Cloudflare Pages:** crie um projeto e envie a pasta. `_headers` também vale.
- **Vercel:** envie a pasta; `vercel.json` aplica os headers.
- **Hospedagem comum (Apache/cPanel):** envie tudo para `public_html`; `.htaccess` aplica os headers.
Depois, ligue um domínio e ative HTTPS (as opções acima já oferecem).

## Segurança aplicada
- Content-Security-Policy restritiva: só scripts e estilos do próprio site, sem inline, sem eval e sem conexões externas.
- Sem `innerHTML`: o conteúdo é montado com `textContent` (sem risco de XSS).
- Links externos com `rel="noopener noreferrer"`.
- Headers: HSTS, nosniff, anti-clickjacking (X-Frame-Options e frame-ancestors), Referrer-Policy, Permissions-Policy, COOP/CORP.
- `.htaccess` bloqueia listagem de pastas e arquivos ocultos.
- Na prática: use senha forte e verificação em duas etapas na hospedagem, no domínio e no WhatsApp Business.

## Como editar preços
Abra `assets/script.js` e altere a lista no início. Formato: `["Nome","Descrição","20,00"]`. Com `~` antes do preço ("~12,00") aparece "a partir de". O número do WhatsApp fica na variável `WA`.
